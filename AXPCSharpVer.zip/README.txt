Nguồn tham khảo:
https://github.com/liuguangw/TlbbGmTool

+ Các method đọc dữ liệu từ AXP copy hoàn toàn từ project trên, chỉ bổ sung thêm phần tạo từ thư mục và một số method phụ trợ.
+ axp 	 : đọc cấu trúc, xác định offset của các tệp được nén trong .axp
+ dbc	 : đọc và tái cấu trúc các tệp
+ sample : ví dụ tạo / giải nén

Chỉ làm theo những gì mình hiểu nên chắc chắn sẽ có lỗi, và có thể sẽ không hoạt động với một số phiên bản hoặc các tệp .axp bị mã hoá, thay đổi cấu trúc, ...!